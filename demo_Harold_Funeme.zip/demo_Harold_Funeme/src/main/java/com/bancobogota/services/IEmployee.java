package com.bancobogota.services;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.bancobogota.models.Employee;


public interface IEmployee {

    public List<Employee> findAll();
	
	public Page<Employee> findAll( Pageable pageable);
	
	public Employee findById(Integer id);
	
	public Employee save(Employee employee);
	
	public void deleteById(Integer id);
}

package com.bancobogota.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bancobogota.models.Employee;
import com.bancobogota.services.IEmployee;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins= {"http://localhost:4200"})
@RestController
@RequestMapping ("/apiBancoBogota")
public class EmployeeRestControler {
	
	@Autowired
	private IEmployee employeeDao;
	
	@PostMapping("/save/employee")
	public  ResponseEntity<?> save ( @RequestBody Employee employee) {
		Map<String, Object> response = new HashMap<>();
		Employee employeeSaved = null;
		
		if (employee == null) {
			response.put("error", "no se pudo guardar datos");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.NOT_FOUND);
			
		} else if (employeeDao.findById(employee.getIdemployee()) != null ) {
			response.put("mensaje", "Ya existe el empleado");
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			
		}else  {
			employeeSaved = employeeDao.save( employee );
			response.put("mensaje", "guardar datos");
			response.put("cliente guardado:", employeeSaved);
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			
		}
		
		
	}
	
	@GetMapping("/employees")
	public List<Employee> index(){	
		return employeeDao.findAll();
	}
	

	@PutMapping("/update/{id}")
	public ResponseEntity<?>  update(@RequestBody Employee employee, @PathVariable Integer id) {
		Map<String, Object> response = new HashMap<>();
		Employee employeeActual = employeeDao.findById(id);
		
		if (employeeActual == null) {
			response.put("mensaje", "Error no se puede editar el cliente con el ID: ".concat(id.toString()).concat(" por que no existe"));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.NOT_FOUND);
		}
		
		try {
			employeeActual.setFullname(employee.getFullname());
			employeeActual.setFunctions(employee.getFunctions());
			employeeActual.setIdboss(employee.getIdboss());
			
		} catch (DataAccessException e) {
			response.put("mensaje", "Error al actualizar en la  base de datos");
			response.put("errors", e.getMessage().concat(": ").concat(e.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
			
		}

		return null;
		
		
	}
	
	@DeleteMapping("/employee/{id}")
	public ResponseEntity<?> delete (@PathVariable Integer id) {

		Map<String, Object> response = new HashMap<>();
	
			try {
				employeeDao.deleteById(id);
				response.put("mensaje", "el empleado fue borrado con exito");

			} catch (Exception e) {
				response.put("mensaje ", "no se pudo borrar el empleaod");
				response.put("error ",e.getMessage());
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
			
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
		
		
		
	}

}

import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employees } from '../components/employee/Empoyee.model';

@Injectable({
  providedIn: 'root'
})
export class EpmployeesService {

  url = 'http://localhost:8080/apiBancoBogota';
  private _notificarUpload = new EventEmitter();

  constructor(
    private http: HttpClient
  ) { }

  getEmployees() {
    return this.http.get<any>(`${this.url}/employees`);
  }

  deletEmployee(id: number) {
    return this.http.delete<any>(`${this.url}/employee/${id}`);
  }

  crearEmployee(form: Employees) {
    const body: object = {
      "idemployee": form.idemployee,
      "idboss": form.idboss,
      "fullname": form.fullname,
      "functions": form.functions
    }
    return this.http.post<any>(`${this.url}/save/employee`, body);
  }



  get notificarUpload() {
    return this._notificarUpload
  }
}

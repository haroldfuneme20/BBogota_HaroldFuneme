import { TestBed } from '@angular/core/testing';

import { EpmployeesService } from './epmployees.service';

describe('EpmployeesService', () => {
  let service: EpmployeesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EpmployeesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

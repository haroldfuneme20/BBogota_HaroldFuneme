import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { EpmployeesService } from '../../services/epmployees.service';
import { Employees } from '../employee/Empoyee.model';
import swal from 'sweetalert2';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  titulo = 'Form Employees';

  formulario: FormGroup;
  id: string;
  employees: Employees [] = [];
  employeesAtuales: Employees [] = [];
  hasIdBoss: boolean = false;


  constructor(
    private _formBilder: FormBuilder,
    private router: Router,
    private activRoute: ActivatedRoute,
    public _es: EpmployeesService
    

  ) { 

  }

  ngOnInit(): void {
    this.id = this.activRoute.snapshot.paramMap.get('id');
    console.log("id es = : " + this.id);
    if (this.id != null ) {
      this.crearFormulario();
      this.cargarDataFormulario();
    }
    this.crearFormulario();
  }

  crearFormulario() {
    this.formulario = this._formBilder.group({
      idemployee: ['', [Validators.required]],
      idboss: ['', []],
      fullname: ['', [Validators.required]],
      functions: ['', [Validators.required]]
    });
  }



  guardar(form) {
    console.log(form);
    this._es.deletEmployee(form.idemployee).subscribe();
    
    setTimeout(() => {
      this._es.crearEmployee(form).subscribe( resp => {
        console.log(resp);
      });
      this.router.navigate(['/home']);
    }, 900);
  }

  cargarDataFormulario() {
    this._es.getEmployees().subscribe( resp => {
      this.employees = resp;
      this.formulario.reset({
        idemployee: this.employees[this.id].idemployee,
        idboss: this.employees[this.id].idboss,
        fullname: this.employees[this.id].fullname,
        functions: this.employees[this.id].functions,
        });
    });
  }

  crear(form){
    console.log(form);
    let idbossAct = parseInt(form.idboss);

      // employees.forEach( employeeAct => { employeeAct.idboss == idbossAct ? this.hasIdBoss = true: this.hasIdBoss = false });
        // console.log(employeeAct);
        // if (employeeAct.idboss === idbossAct ) {
        //   return this.hasIdBoss = true;
        // }

      console.log(this.hasIdBoss);

    this._es.crearEmployee(form).subscribe( resp => {
      console.log(resp.status);
      console.log(this.hasIdBoss);
      if (resp.mensaje === 'guardar datos') {
        swal.fire({
          position: 'center',
          icon: 'success',
          title: 'Your work has been saved',
          showConfirmButton: false,
          timer: 1500
        })
        setTimeout(() => {
          this.router.navigate(['/home']);
        }, 900);
      }
    },
    err => {
      swal.fire({
        icon: 'error',
        title: 'Oops something was wrong',
        text: 'Something went wrong!' + 'Error: ' + err.error.error,
        footer: '<a href>Why do I have this issue?</a>'
      });
    }
    );

    console.log(this.hasIdBoss);
    swal.fire({
      icon: 'error',
      title: 'Oops Something went wrong',
      text: 'Error: ' + 'Employee exist',
      footer: '<a href>Why do I have this issue?</a>'
      });

  

 
    
  }
}

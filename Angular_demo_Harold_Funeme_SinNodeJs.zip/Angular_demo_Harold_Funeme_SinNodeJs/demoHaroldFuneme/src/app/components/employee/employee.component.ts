import { Component, OnInit, OnChanges } from '@angular/core';
import { Employees } from './Empoyee.model';
import { EpmployeesService } from '../../services/epmployees.service';
import swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit, OnChanges {

  employees: Employees [];
  constructor(
    public _es: EpmployeesService,
    public router: Router
  ) { }

  ngOnInit(): void {
    this.getEmployees();
  }

  ngOnChanges(changes): void {
    this.getEmployees();
    
  }

  getEmployees() {
    this._es.getEmployees().subscribe( response => {
      console.log(response);
      this.employees = response;
    });
  }

  delete(employee: Employees) {
    const swalWithBootstrapButtons = swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })
    swalWithBootstrapButtons.fire({
      title: `Eliminar Cliente`,
      text: `esta seguro de elminiar a ${employee.fullname}??`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Si, Eliminar!',
      cancelButtonText: 'No, cancelar!',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        this._es.deletEmployee(employee.idemployee).subscribe( response => {
            this.employees = this.employees.filter( cli => cli !== response);
            swalWithBootstrapButtons.fire(
              'Deleted!',
              'Your file has been deleted.',
              'success'
            )
          });
      } else if (
        /* Read more about handling dismissals below */
        result.dismiss === swal.DismissReason.cancel
      ) {
        swalWithBootstrapButtons.fire(
          'Cancelled',
          'Your imaginary file is safe :)',
          'error'
        )
      }
    })
    
  }

}

export class Employees {
    idemployee: number;
    idboss: number;
    fullname: string;
    functions: string;
}